﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static string[,] table = new string[15, 15];
        static int Realization(string player) {
            int ran_x;
            int ran_y;
            int min_x = 0;
            int max_x;
            int min_y = 0;
            int max_y;
            int counter = 0;
            string winner = " ";
                while (true)
                {
                    Random r = new Random();
                    ran_x = r.Next(0, 15);
                    ran_y = r.Next(0, 15);
                    if (table[ran_x, ran_y] == "_")
                    {
                        break;
                    }
                }
                table[ran_x, ran_y] = player;
                if (ran_x > 4)
                {
                    min_x = ran_x - 4;
                    if (ran_x + 4 > 15)
                    {
                        max_x = 15;
                    }
                    else
                    {
                        max_x = ran_x + 4;
                    }
                }
                else
                {
                    max_x = ran_x + 4;
                }

                if (ran_y > 4)
                {
                    min_y = ran_y - 4;
                    if (ran_y + 4 > 15)
                    {
                        max_y = 15;
                    }
                    else
                    {
                        max_y = ran_y + 4;
                    }
                }
                else
                {
                    max_y = ran_y + 4;
                }
                //horizontal
                for (int i = min_x; i < max_x; i++)
                {
                    if (table[i, ran_y] == player)
                    {
                        counter++;
                    }
                    else
                    {
                        counter = 0;
                    }
                    if (counter > 4)
                    {
                    if (player == "x")
                    {
                        return 1;
                    }
                    else
                    {
                        return 2;
                    }
                    }
                }
                //vertical
                for (int i = min_y; i < max_y; i++)
                {
                    if (table[ran_x, i] == player)
                    {
                        counter++;
                    }
                    else
                    {
                        counter = 0;
                    }
                    if (counter > 4)
                    {
                    if (player == "x")
                    {
                        return 1;
                    }
                    else
                    {
                        return 2;
                    }
                    }
                }
                //diagonal 1
                int temp = min_y;
                for (int i = min_x; i < max_x; i++)
                {
                    if (table[i, temp] == player)
                    {
                        counter++;
                    }
                    else
                    {
                        counter = 0;
                    }
                if (counter > 4)
                    {
                    if (player == "x")
                    {
                        return 1;
                    }
                    else
                    {
                        return 2;
                    }
                    }
                    temp++;
                    if (temp >= max_y)
                    {
                        break;
                    }
                }
                //diagonal 2
                int temp1 = max_y-1;
                for (int i = min_x; i < max_x; i++)
                {
                    if (table[i, temp1] == player)
                    {
                        counter++;
                    }
                    else
                    {
                        counter = 0;
                    }
                if (counter > 4)
                    {
                    if(player == "x")
                    {
                        return 1;
                    }
                    else {
                        return 2;
                    }
                    }
                    temp1--;
                    if (temp1 < min_y)
                    {
                        break;
                    }
                }
            return 0;
        }
        static void Hod() {
            int win1 = 0;
            int win2 = 0;
            while (true)
            {
                win1 = Realization("x");
                win2 = Realization("o");
                if(win1!=0)
                {
                    Console.WriteLine(win1 + " player win!!!");
                    break;
                }
                if (win2 != 0)
                {
                    Console.WriteLine(win2 + " player win!!!");
                    break;
                }
            }
        } 
        static void Main(string[] args)
        {
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    table[i, j] = "_";
                }
            }
            Hod();
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    Console.Write(table[i,j] + " ");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }


    }
}
